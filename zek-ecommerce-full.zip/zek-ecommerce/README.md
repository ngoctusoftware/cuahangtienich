# ZEK Agency – Hệ thống bán hàng (Laravel) – Phase 1: Kiến trúc & Database

Đây là **Phase 1/3** của dự án:
1. ✅ **Kiến trúc + Database + Design Pattern** (nội dung của gói này)
2. ⏭ Giao diện website bán hàng (theo ảnh mẫu 1)
3. ⏭ Giao diện Admin quản trị (theo ảnh mẫu 2)

## 1. Design pattern sử dụng

- **Repository Pattern**: `app/Repositories/Contracts/*Interface.php` định nghĩa hợp đồng,
  `app/Repositories/Eloquent/*.php` là cài đặt cụ thể bằng Eloquent. Controller/Service không
  bao giờ gọi trực tiếp Eloquent Model — chỉ gọi qua Interface. Giúp dễ test (mock interface),
  dễ đổi nguồn dữ liệu sau này mà không sửa code tầng trên.
- **Service Layer**: `app/Services/*.php` chứa toàn bộ business logic (tính giỏ hàng, tạo đơn
  hàng, đa ngôn ngữ, cache settings...). Controller chỉ gọi Service, giữ Controller mỏng ("thin
  controller, fat service").
- **Dependency Injection**: `app/Providers/RepositoryServiceProvider.php` bind Interface →
  Implementation, Laravel tự động inject đúng lớp khi type-hint Interface trong constructor.
- **Queue (Job)**: `app/Jobs/SendOrderConfirmationEmail.php` – các tác vụ chậm (gửi email, gửi
  thông báo) được đẩy vào hàng đợi thay vì xử lý đồng bộ, để phản hồi cho khách nhanh hơn.
- **Cache (Redis)**: `SettingService`, `ProductRepository`, `CategoryRepository`,
  `LanguageService` đều cache qua `Cache::remember()`/`Cache::tags()` — khi đổi driver cache
  sang `redis` trong `.env`, toàn bộ tự động dùng Redis mà không sửa code.
- **Đa ngôn ngữ (i18n dữ liệu)**: dùng mô hình *Translation table* (`product_translations`,
  `category_translations`, `content_translations`) thay vì cột đa ngôn ngữ trong 1 bảng — cho
  phép admin thêm ngôn ngữ mới không cần sửa schema.

## 2. Cấu trúc thư mục đã tạo

```
app/
  Models/               Eloquent models (Product, Category, Order, Customer, User, Role...)
  Repositories/
    Contracts/          Interface (hợp đồng)
    Eloquent/           Cài đặt cụ thể
  Services/             Business logic (ProductService, OrderService, CartService...)
  Jobs/                 Queue jobs
  Providers/
    RepositoryServiceProvider.php
database/
  migrations/           12 file migration (settings, languages, roles, permissions, users,
                         customer_groups, customers, categories, products, orders, payments,
                         contents...)
  seeders/               Seed ngôn ngữ mặc định + phân quyền + tài khoản admin đầu tiên
```

## 3. Cách tích hợp vào dự án Laravel thật

Bạn đã có sẵn môi trường (PHP + Composer + MySQL + Redis), làm theo các bước sau:

```bash
# 1. Tạo project Laravel mới (nếu chưa có)
composer create-project laravel/laravel zek-agency
cd zek-agency

# 2. Copy các thư mục app/ và database/ từ gói này đè vào project
#    (giữ nguyên các file mặc định khác của Laravel, chỉ thêm/merge)

# 3. Cấu hình .env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=zek_agency
DB_USERNAME=root
DB_PASSWORD=

CACHE_STORE=redis
QUEUE_CONNECTION=redis
SESSION_DRIVER=redis
REDIS_HOST=127.0.0.1
REDIS_PORT=6379

# 4. Cài driver cache tags (Laravel 11 mặc định KHÔNG hỗ trợ Cache::tags() với driver "database"/"file",
#    driver "redis" thì hỗ trợ – đã cấu hình ở trên nên OK)

# 5. Chạy migration + seed
php artisan migrate --seed

# 6. Chạy queue worker (bắt buộc để job gửi email chạy)
php artisan queue:work redis

# 7. Chạy thử
php artisan serve
```

Tài khoản admin mặc định sau khi seed: `admin@zekagency.vn / Admin@123` (đổi mật khẩu ngay
sau khi đăng nhập lần đầu).

## 4. Sơ đồ quan hệ dữ liệu chính (rút gọn)

- `categories` 1—n `products`, tự tham chiếu `parent_id` (danh mục cha/con)
- `products` 1—n `product_translations`, `product_images`
- `customers` 1—n `orders` 1—n `order_items`, `orders` 1—1 `payments`
- `users` n—n `roles` n—n `permissions` (RBAC – phân quyền)
- `languages` được tham chiếu bởi mọi bảng `*_translations` để hỗ trợ đa ngôn ngữ

## 5. Việc tiếp theo (Phase 2 & 3)

- **Phase 2**: Controller + View (Blade/Bootstrap) tái tạo giao diện website bán hàng giống
  ảnh mẫu 1 (header, banner, dịch vụ, sản phẩm nổi bật, testimonial, footer...), giỏ hàng,
  thanh toán COD/chuyển khoản/online, widget Zalo/Messenger/Phone, chuyển đổi ngôn ngữ.
- **Phase 3**: Controller + View Admin (theo layout ảnh mẫu 2 – sidebar, dashboard, bảng biểu)
  cho toàn bộ 12 nhóm chức năng quản trị đã liệt kê (settings, nội dung, danh mục, sản phẩm,
  người dùng, phân quyền, đơn hàng, thanh toán, nhóm khách hàng, khách hàng, ngôn ngữ).

Trả lời "tiếp tục phase 2" hoặc "tiếp tục phase 3" để tôi triển khai tiếp phần đó.

---

# Phase 2: Giao diện Website bán hàng (đã hoàn thành)

## 1. Những gì đã có

- **Layout**: `resources/views/layouts/app.blade.php` + `partials/header.blade.php`,
  `partials/footer.blade.php`, `partials/widgets.blade.php` (Zalo/Messenger/Phone nổi góc màn hình)
- **Trang chủ** (`home/index.blade.php`): hero banner, dải logo thương hiệu, 3 khối sản phẩm
  (Nổi bật / Bán chạy / Mới về), "Lý do nên chọn", testimonial khách hàng, CTA, tin tức — bám sát
  bố cục & phong cách màu (gradient tím → hồng) của ảnh mẫu 1, áp dụng cho ecommerce.
- **Sản phẩm**: `products/index.blade.php` (danh sách theo danh mục, có filter sidebar + phân
  trang), `products/show.blade.php` (chi tiết sản phẩm, gallery ảnh, thêm giỏ hàng),
  `products/partials/card.blade.php` (card sản phẩm tái sử dụng)
- **Giỏ hàng** (`cart/index.blade.php`) lưu trong Session qua `CartService` (Phase 1)
- **Thanh toán** (`checkout/index.blade.php`, `checkout/success.blade.php`): COD, chuyển khoản,
  online — tạo đơn hàng qua `OrderService::checkout()` (đã có transaction + queue email ở Phase 1)
- **Đăng nhập/Đăng ký khách hàng**: `auth/customer/login.blade.php`,
  `auth/customer/register.blade.php`, `auth/customer/orders.blade.php` — dùng guard riêng
  `customer` (tách biệt hoàn toàn với guard `web` của Admin ở Phase 3)
- **Đa ngôn ngữ**: nút chuyển ngôn ngữ ở header, route `lang.switch` gọi `LanguageService::setLocale()`
- **CSS**: `public/css/app.css` — theme màu gradient tím/hồng đồng bộ toàn site
- **View Composer**: `app/View/Composers/ShopComposer.php` tự động bơm `$siteName`,
  `$languages`, `$menuCategories`, `$cartCount`, hàm `$setting()` vào mọi view — Controller không
  cần lặp lại code này

## 2. Controllers đã tạo

| Controller | Chức năng |
|---|---|
| `Shop/HomeController` | Trang chủ, lấy 3 khối sản phẩm từ `ProductService` |
| `Shop/ProductController` | Danh sách theo danh mục, sản phẩm mới/bán chạy, chi tiết |
| `Shop/CartController` | Thêm/sửa/xoá giỏ hàng (session) |
| `Shop/CheckoutController` | Xem trang thanh toán, tạo đơn hàng, trang thành công |
| `Shop/LanguageController` | Đổi ngôn ngữ hiển thị |
| `Shop/PageController` | Hiển thị trang tĩnh (giới thiệu, liên hệ...) từ bảng `contents` |
| `Auth/CustomerAuthController` | Đăng nhập / đăng ký / đăng xuất / đơn hàng của khách |

## 3. Việc cần làm thêm khi tích hợp vào project thật

1. Copy toàn bộ `app/`, `resources/`, `routes/web.php`, `public/css`, `public/js` vào project
   Laravel (đè/merge, **không ghi đè** `routes/web.php` gốc nếu bạn đã có nội dung khác — merge
   thủ công).
2. Mở `config/auth.php`, merge nội dung từ `config/auth.snippet.php` (thêm guard `customer`).
3. Chạy `php artisan storage:link` (để `asset('storage/...')` cho ảnh sản phẩm hoạt động).
4. Thêm ảnh thật vào `public/images/` (logo, hero-banner, brands, why-choose...) — hiện dùng
   `onerror` để tự ẩn ảnh placeholder chưa có, tránh vỡ giao diện khi demo.
5. Cấu hình `.env` `APP_LOCALE=vi`, danh sách locale hỗ trợ nếu dùng thêm chuỗi tĩnh (`__()`),
   hiện tại phần dịch nội dung (tên sản phẩm, danh mục...) đã nằm trong DB (translation tables).

## 4. Phase 3 (đã hoàn thành): Giao diện Admin

### Những gì đã có

- **Layout Admin**: `resources/views/admin/layouts/app.blade.php` + sidebar tối / topbar
  (`admin/partials/sidebar.blade.php`, `topbar.blade.php`) — bố cục lấy cảm hứng từ ảnh mẫu 2
  (sidebar cố định bên trái, top bar tìm kiếm + user menu, thẻ thống kê, bảng dữ liệu).
- **Dashboard**: `admin/dashboard.blade.php` — 4 thẻ chỉ số (đơn hôm nay, doanh thu tháng, khách
  mới, tổng sản phẩm), bảng đơn hàng gần đây, danh sách sản phẩm sắp hết hàng.
- **CRUD đầy đủ (index + form) cho toàn bộ 12 nhóm chức năng đã yêu cầu**:

| Nhóm chức năng | Controller | Views |
|---|---|---|
| Cấu hình chung (logo, tên site, hotline...) | `SettingController` | `admin/settings/index` |
| Quản lý nội dung (CMS: trang, block, tin tức) | `ContentController` | `admin/contents/*` |
| Danh mục (đa cấp, đa ngôn ngữ) | `CategoryController` | `admin/categories/*` |
| Sản phẩm (ảnh, giá, kho, đa ngôn ngữ) | `ProductController` | `admin/products/*` |
| Người dùng (admin/nhân viên) | `UserController` | `admin/users/*` |
| Phân quyền (Role – Permission) | `RoleController` | `admin/roles/*` |
| Đơn hàng | `OrderController` | `admin/orders/*` |
| Thanh toán | `PaymentController` | `admin/payments/index` |
| Nhóm khách hàng | `CustomerGroupController` | `admin/customer-groups/*` |
| Khách hàng | `CustomerController` | `admin/customers/*` |
| Ngôn ngữ | `LanguageController` | `admin/languages/*` |
| Đăng nhập Admin | `Auth/AdminAuthController` | `admin/auth/login` |

- **Phân quyền (RBAC)**: middleware `App\Http\Middleware\EnsurePermission` (alias `permission`)
  kiểm tra `$user->hasPermission('products.create')` hoặc vai trò `super-admin` trước khi cho vào
  từng route — đã gắn sẵn trên toàn bộ `routes/admin.php`.
- **CSS riêng cho Admin**: `public/css/admin.css` (theme tối, đồng bộ phong cách dashboard ở ảnh
  mẫu 2).

### Việc cần làm thêm khi tích hợp

1. Copy `app/Http/Controllers/Admin`, `app/Http/Controllers/Auth/AdminAuthController.php`,
   `app/Http/Middleware/EnsurePermission.php`, `resources/views/admin`, `routes/admin.php`,
   `public/css/admin.css` vào project.
2. Merge `bootstrap.app.snippet.php` vào `bootstrap/app.php` (đăng ký route `admin.php` +
   alias middleware `permission`).
3. Merge `bootstrap.providers.snippet.php` vào `bootstrap/providers.php`.
4. Truy cập `/admin/login`, đăng nhập bằng tài khoản seed sẵn ở Phase 1
   (`admin@zekagency.vn / Admin@123`) — tài khoản này có vai trò `super-admin` nên thấy được toàn
   bộ menu.
5. Vào **Ngôn ngữ** tạo thêm ngôn ngữ nếu cần, vào **Danh mục/Sản phẩm** nhập bản dịch theo từng
   tab ngôn ngữ đã dựng sẵn trong form.

## 5. Tổng kết 3 phase

Bộ 3 gói (Kiến trúc+DB, Website bán hàng, Admin quản trị) đã đáp ứng đủ yêu cầu ban đầu: đăng
nhập khách/admin, sản phẩm mới/bán chạy/nổi bật, giỏ hàng – thanh toán COD/chuyển khoản/online,
widget Zalo/Messenger/Phone, đa ngôn ngữ, quản trị đầy đủ 12 nhóm chức năng, MySQL, Redis
cache, Queue cho email. Phần còn lại là công đoạn tích hợp thủ công (chạy trên máy bạn, cấu hình
`.env`, thêm ảnh thật, kiểm thử) vì môi trường của tôi không cài được Laravel/Composer thật để
chạy demo trực tiếp.
