<?php
/**
 * SNIPPET — merge vào bootstrap/providers.php (Laravel 11/12)
 */

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\RepositoryServiceProvider::class, // Phase 1: bind Repository interfaces
    App\Providers\ViewServiceProvider::class,       // Phase 2: ShopComposer (menu, settings, cart count...)
];
