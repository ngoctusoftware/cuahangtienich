<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('settings', function (Blueprint $table) {
            $table->id();
            $table->string('key')->unique();   // site_name, site_logo, hotline, email, address, zalo_link, fb_messenger, ...
            $table->longText('value')->nullable();
            $table->string('type')->default('text'); // text, image, textarea, json
            $table->string('group')->default('general'); // general, contact, seo, social
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('settings');
    }
};
